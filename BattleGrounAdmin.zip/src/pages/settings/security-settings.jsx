"use client"
import { useState } from "react"
import {
  Box,
  Card,
  CardContent,
  Typography,
  Switch,
  Button,
  TextField,
  Checkbox,
  FormControlLabel,
  IconButton,
  Stack,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  Alert,
  Divider,
  useTheme,
  useMediaQuery,
  Paper,
} from "@mui/material"
import { Shield, Plus, Trash2, Save, Lock, Wifi, Key, CheckCircle } from "lucide-react"

const SecuritySettings = () => {
  const theme = useTheme()
  const isMobile = useMediaQuery(theme.breakpoints.down("sm"))
  const isTablet = useMediaQuery(theme.breakpoints.between("sm", "md"))

  // State management
  const [totpEnabled, setTotpEnabled] = useState(true)
  const [ipRanges, setIpRanges] = useState(["10.0.0.0/8", "10.0.0.0/9"])
  const [minLength, setMinLength] = useState(8)
  const [requireUppercase, setRequireUppercase] = useState(false)
  const [requireNumbers, setRequireNumbers] = useState(true)
  const [requireSpecialChars, setRequireSpecialChars] = useState(true)
  const [showIpModal, setShowIpModal] = useState(false)
  const [newIpRange, setNewIpRange] = useState("")
  const [showSuccess, setShowSuccess] = useState(false)

  // Handlers
  const handleAddIpRange = () => {
    if (newIpRange.trim()) {
      setIpRanges([...ipRanges, newIpRange.trim()])
      setNewIpRange("")
      setShowIpModal(false)
    }
  }

  const handleRemoveIpRange = (index) => {
    setIpRanges(ipRanges.filter((_, i) => i !== index))
  }

  const handleSaveSettings = () => {
    setShowSuccess(true)
    setTimeout(() => setShowSuccess(false), 3000)
  }

  const IpRangeItem = ({ range, index }) => (
    <Paper
      elevation={1}
      sx={{
        p: { xs: 1.5, sm: 2 },
        mb: 1,
        display: "flex",
        alignItems: "center",
        justifyContent: "space-between",
        borderRadius: 2,
        border: "1px solid #f0f0f0",
        "&:hover": {
          borderColor: "#e3f2fd",
          backgroundColor: "#fafafa",
        },
      }}
    >
      <Stack direction="row" alignItems="center" spacing={1}>
        <Wifi size={16} color="#666" />
        <Typography
          variant="body2"
          sx={{
            fontFamily: "monospace",
            fontSize: { xs: "0.8rem", sm: "0.875rem" },
            color: "#333",
          }}
        >
          {range}
        </Typography>
      </Stack>
      <IconButton
        size="small"
        onClick={() => handleRemoveIpRange(index)}
        sx={{
          color: "#f44336",
          "&:hover": {
            backgroundColor: "#ffebee",
          },
        }}
      >
        <Trash2 size={16} />
      </IconButton>
    </Paper>
  )

  return (
    <Box
      sx={{
        minHeight: "100vh",
        backgroundColor: "#fafafa",
        py: { xs: 2, sm: 3, md: 4 },
      }}
    >
      <Box
        sx={{
          width: "95%",
          maxWidth: "95%",
          mx: "auto",
          px: { xs: 1, sm: 1.5, md: 2 },
        }}
      >
        {/* Header */}
        <Card
          elevation={2}
          sx={{
            mb: { xs: 2, sm: 3 },
            borderRadius: { xs: 2, sm: 3 },
            backgroundColor: "#ffffff",
            border: "1px solid #f0f0f0",
          }}
        >
          <CardContent
            sx={{
              p: { xs: 2, sm: 3, md: 4 },
              "&:last-child": { pb: { xs: 2, sm: 3, md: 4 } },
            }}
          >
            <Stack direction="row" alignItems="center" spacing={2}>
              <Box
                sx={{
                  p: 1.5,
                  borderRadius: 2,
                  backgroundColor: "#e3f2fd",
                  display: "flex",
                  alignItems: "center",
                  justifyContent: "center",
                }}
              >
                <Shield size={isMobile ? 20 : 24} color="#1976d2" />
              </Box>
              <Box>
                <Typography
                  variant={isMobile ? "h5" : "h4"}
                  sx={{
                    fontWeight: 700,
                    color: "#1a1a1a",
                    mb: 0.5,
                  }}
                >
                  Security Settings
                </Typography>
                <Typography variant="body2" color="text.secondary" sx={{ fontSize: { xs: "0.8rem", sm: "0.875rem" } }}>
                  Configure authentication and security policies
                </Typography>
              </Box>
            </Stack>
          </CardContent>
        </Card>

        {/* Main Settings Card */}
        <Card
          elevation={2}
          sx={{
            borderRadius: { xs: 2, sm: 3 },
            backgroundColor: "#ffffff",
            border: "1px solid #f0f0f0",
          }}
        >
          <CardContent
            sx={{
              p: { xs: 2, sm: 3, md: 4 },
              "&:last-child": { pb: { xs: 2, sm: 3, md: 4 } },
            }}
          >
            {/* Two-Factor Authentication */}
            <Box sx={{ mb: { xs: 3, sm: 4 } }}>
              <Stack
                direction={{ xs: "column", sm: "row" }}
                justifyContent="space-between"
                alignItems={{ xs: "flex-start", sm: "center" }}
                spacing={2}
                sx={{
                  p: { xs: 2, sm: 3 },
                  borderRadius: 2,
                  backgroundColor: "#f8f9fa",
                  border: "1px solid #e9ecef",
                }}
              >
                <Box>
                  <Stack direction="row" alignItems="center" spacing={1.5} sx={{ mb: 0.5 }}>
                    <Key size={18} color="#1976d2" />
                    <Typography
                      variant="h6"
                      sx={{
                        fontWeight: 600,
                        fontSize: { xs: "1rem", sm: "1.1rem" },
                      }}
                    >
                      Two-Factor Authentication (TOTP)
                    </Typography>
                  </Stack>
                  <Typography variant="body2" color="text.secondary" sx={{ fontSize: { xs: "0.75rem", sm: "0.8rem" } }}>
                    Require 2FA for all admin accounts
                  </Typography>
                </Box>
                <Switch
                  checked={totpEnabled}
                  onChange={(e) => setTotpEnabled(e.target.checked)}
                  size={isMobile ? "medium" : "large"}
                  sx={{
                    "& .MuiSwitch-switchBase.Mui-checked": {
                      color: "#1976d2",
                    },
                    "& .MuiSwitch-switchBase.Mui-checked + .MuiSwitch-track": {
                      backgroundColor: "#1976d2",
                    },
                  }}
                />
              </Stack>
            </Box>

            <Divider sx={{ my: { xs: 3, sm: 4 } }} />

            {/* IP Whitelist */}
            <Box sx={{ mb: { xs: 3, sm: 4 } }}>
              <Stack direction="row" alignItems="center" spacing={1.5} sx={{ mb: 2 }}>
                <Wifi size={18} color="#1976d2" />
                <Typography
                  variant="h6"
                  sx={{
                    fontWeight: 600,
                    fontSize: { xs: "1rem", sm: "1.1rem" },
                  }}
                >
                  IP Whitelist (CIDR format)
                </Typography>
              </Stack>

              <Box sx={{ mb: 2 }}>
                {ipRanges.map((range, index) => (
                  <IpRangeItem key={index} range={range} index={index} />
                ))}
              </Box>

              <Button
                variant="outlined"
                startIcon={<Plus size={16} />}
                onClick={() => setShowIpModal(true)}
                sx={{
                  borderRadius: 2,
                  textTransform: "none",
                  fontSize: { xs: "0.8rem", sm: "0.875rem" },
                  px: { xs: 2, sm: 3 },
                  py: 1,
                }}
              >
                Add IP Range
              </Button>
            </Box>

            <Divider sx={{ my: { xs: 3, sm: 4 } }} />

            {/* Password Policy */}
            <Box>
              <Stack direction="row" alignItems="center" spacing={1.5} sx={{ mb: 3 }}>
                <Lock size={18} color="#1976d2" />
                <Typography
                  variant="h6"
                  sx={{
                    fontWeight: 600,
                    fontSize: { xs: "1rem", sm: "1.1rem" },
                  }}
                >
                  Password Policy
                </Typography>
              </Stack>

              <Stack spacing={3}>
                {/* Minimum Length */}
                <Box>
                  <Typography
                    variant="subtitle2"
                    sx={{
                      mb: 1,
                      fontWeight: 600,
                      fontSize: { xs: "0.8rem", sm: "0.875rem" },
                    }}
                  >
                    Minimum Length
                  </Typography>
                  <TextField
                    type="number"
                    value={minLength}
                    onChange={(e) => setMinLength(Number.parseInt(e.target.value) || 0)}
                    size={isMobile ? "small" : "medium"}
                    sx={{
                      width: { xs: "100%", sm: 120 },
                      "& .MuiOutlinedInput-root": {
                        borderRadius: 2,
                      },
                    }}
                    inputProps={{ min: 1, max: 50 }}
                  />
                </Box>

                {/* Password Requirements */}
                <Box>
                  <Typography
                    variant="subtitle2"
                    sx={{
                      mb: 2,
                      fontWeight: 600,
                      fontSize: { xs: "0.8rem", sm: "0.875rem" },
                    }}
                  >
                    Requirements
                  </Typography>
                  <Stack spacing={1}>
                    <FormControlLabel
                      control={
                        <Checkbox
                          checked={requireUppercase}
                          onChange={(e) => setRequireUppercase(e.target.checked)}
                          size={isMobile ? "medium" : "large"}
                        />
                      }
                      label={
                        <Typography sx={{ fontSize: { xs: "0.8rem", sm: "0.875rem" } }}>Require Uppercase</Typography>
                      }
                    />
                    <FormControlLabel
                      control={
                        <Checkbox
                          checked={requireNumbers}
                          onChange={(e) => setRequireNumbers(e.target.checked)}
                          size={isMobile ? "medium" : "large"}
                        />
                      }
                      label={
                        <Typography sx={{ fontSize: { xs: "0.8rem", sm: "0.875rem" } }}>Require Numbers</Typography>
                      }
                    />
                    <FormControlLabel
                      control={
                        <Checkbox
                          checked={requireSpecialChars}
                          onChange={(e) => setRequireSpecialChars(e.target.checked)}
                          size={isMobile ? "medium" : "large"}
                        />
                      }
                      label={
                        <Typography sx={{ fontSize: { xs: "0.8rem", sm: "0.875rem" } }}>
                          Require Special Characters
                        </Typography>
                      }
                    />
                  </Stack>
                </Box>
              </Stack>
            </Box>

            <Divider sx={{ my: { xs: 3, sm: 4 } }} />

            {/* Save Button */}
            <Box sx={{ display: "flex", justifyContent: "flex-start" }}>
              <Button
                variant="contained"
                startIcon={<Save size={18} />}
                onClick={handleSaveSettings}
                sx={{
                  borderRadius: 2,
                  textTransform: "none",
                  fontSize: { xs: "0.9rem", sm: "1rem" },
                  px: { xs: 3, sm: 4 },
                  py: { xs: 1.5, sm: 2 },
                  backgroundColor: "#1a1a1a",
                  "&:hover": {
                    backgroundColor: "#333",
                  },
                }}
              >
                Save Security Settings
              </Button>
            </Box>
          </CardContent>
        </Card>

        {/* Success Alert */}
        {showSuccess && (
          <Alert
            severity="success"
            icon={<CheckCircle size={20} />}
            sx={{
              mt: 2,
              borderRadius: 2,
              "& .MuiAlert-message": {
                fontSize: { xs: "0.8rem", sm: "0.875rem" },
              },
            }}
          >
            Security settings saved successfully!
          </Alert>
        )}

        {/* IP Range Modal */}
        <Dialog
          open={showIpModal}
          onClose={() => setShowIpModal(false)}
          maxWidth="sm"
          fullWidth
          PaperProps={{
            sx: {
              borderRadius: 3,
              m: { xs: 1, sm: 2 },
            },
          }}
        >
          <DialogTitle
            sx={{
              pb: 1,
              fontSize: { xs: "1.1rem", sm: "1.25rem" },
              fontWeight: 600,
            }}
          >
            v0-battle-nation-admin-portal.vercel.app says
          </DialogTitle>
          <DialogContent sx={{ pb: 2 }}>
            <Typography
              variant="body2"
              sx={{
                mb: 2,
                fontSize: { xs: "0.8rem", sm: "0.875rem" },
              }}
            >
              Enter IP address or CIDR range:
            </Typography>
            <TextField
              fullWidth
              value={newIpRange}
              onChange={(e) => setNewIpRange(e.target.value)}
              placeholder="e.g., 192.168.1.0/24"
              size={isMobile ? "small" : "medium"}
              sx={{
                "& .MuiOutlinedInput-root": {
                  borderRadius: 2,
                },
              }}
              onKeyPress={(e) => {
                if (e.key === "Enter") {
                  handleAddIpRange()
                }
              }}
            />
          </DialogContent>
          <DialogActions sx={{ p: 2, pt: 0 }}>
            <Button
              onClick={() => setShowIpModal(false)}
              sx={{
                textTransform: "none",
                color: "#666",
                fontSize: { xs: "0.8rem", sm: "0.875rem" },
              }}
            >
              Cancel
            </Button>
            <Button
              onClick={handleAddIpRange}
              variant="contained"
              sx={{
                textTransform: "none",
                borderRadius: 2,
                fontSize: { xs: "0.8rem", sm: "0.875rem" },
              }}
            >
              OK
            </Button>
          </DialogActions>
        </Dialog>
      </Box>
    </Box>
  )
}

export default SecuritySettings
