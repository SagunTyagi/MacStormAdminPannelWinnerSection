"use client"
import { useState } from "react"
import {
  Box,
  Card,
  CardContent,
  Typography,
  Button,
  IconButton,
  Stack,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  TextField,
  useTheme,
  useMediaQuery,
  Paper,
} from "@mui/material"
import { HelpCircle, Plus, ExternalLink, X, Save } from "lucide-react"

const FAQComponent = () => {
  const theme = useTheme()
  const isMobile = useMediaQuery(theme.breakpoints.down("sm"))
  const isTablet = useMediaQuery(theme.breakpoints.between("sm", "md"))

  // State management
  const [showAddModal, setShowAddModal] = useState(false)
  const [newFAQ, setNewFAQ] = useState({
    question: "",
    answer: "",
  })

  const [faqs, setFaqs] = useState([
    {
      id: 1,
      question: "How do I join a tournament?",
      answer: "Navigate to the tournaments section, select a tournament, and click 'Join' after paying the entry fee.",
    },
    {
      id: 2,
      question: "What happens if I lose my match code?",
      answer: "Contact support immediately. We can regenerate match codes before the match starts.",
    },
    {
      id: 3,
      question: "How are winners determined?",
      answer: "Winners are determined based on match results verified through screenshots and game APIs.",
    },
  ])

  // Handlers
  const handleAddFAQ = () => {
    if (newFAQ.question.trim() && newFAQ.answer.trim()) {
      const newFAQItem = {
        id: faqs.length + 1,
        question: newFAQ.question.trim(),
        answer: newFAQ.answer.trim(),
      }
      setFaqs([...faqs, newFAQItem])
      setNewFAQ({ question: "", answer: "" })
      setShowAddModal(false)
    }
  }

  const handleCloseModal = () => {
    setShowAddModal(false)
    setNewFAQ({ question: "", answer: "" })
  }

  const FAQItem = ({ faq }) => (
    <Paper
      elevation={1}
      sx={{
        mb: { xs: 1.5, sm: 2 },
        borderRadius: 2,
        border: "1px solid #f0f0f0",
        transition: "all 0.2s ease-in-out",
        "&:hover": {
          elevation: 2,
          borderColor: "#e3f2fd",
          backgroundColor: "#fafafa",
        },
      }}
    >
      <CardContent
        sx={{
          p: { xs: 2, sm: 3 },
          "&:last-child": { pb: { xs: 2, sm: 3 } },
        }}
      >
        <Stack direction="row" justifyContent="space-between" alignItems="flex-start" spacing={2}>
          <Box sx={{ flex: 1, minWidth: 0 }}>
            <Typography
              variant={isMobile ? "subtitle1" : "h6"}
              sx={{
                fontWeight: 600,
                mb: { xs: 1, sm: 1.5 },
                color: "#1a1a1a",
                fontSize: { xs: "1rem", sm: "1.1rem", md: "1.2rem" },
                lineHeight: 1.3,
              }}
            >
              {faq.question}
            </Typography>
            <Typography
              variant="body2"
              color="text.secondary"
              sx={{
                fontSize: { xs: "0.85rem", sm: "0.9rem" },
                lineHeight: 1.5,
                color: "#666",
              }}
            >
              {faq.answer}
            </Typography>
          </Box>
          <IconButton
            size="small"
            sx={{
              color: "#666",
              flexShrink: 0,
              mt: 0.5,
              "&:hover": {
                color: "#1976d2",
                backgroundColor: "#f3f4f6",
              },
            }}
          >
            <ExternalLink size={isMobile ? 16 : 18} />
          </IconButton>
        </Stack>
      </CardContent>
    </Paper>
  )

  return (
    <Box
      sx={{
        minHeight: "100vh",
        backgroundColor: "#fafafa",
        py: { xs: 2, sm: 3, md: 4 },
      }}
    >
      <Box
        sx={{
          width: "95%",
          maxWidth: "95%",
          mx: "auto",
          px: { xs: 1, sm: 1.5, md: 2 },
        }}
      >
        {/* FAQ Content */}
        <Card
          elevation={2}
          sx={{
            borderRadius: { xs: 2, sm: 3 },
            backgroundColor: "#ffffff",
            border: "1px solid #f0f0f0",
          }}
        >
          <CardContent
            sx={{
              p: { xs: 2, sm: 3, md: 4 },
              "&:last-child": { pb: { xs: 2, sm: 3, md: 4 } },
            }}
          >
            {/* Header */}
            <Stack direction="row" alignItems="center" spacing={2} sx={{ mb: { xs: 3, sm: 4 } }}>
              <Box
                sx={{
                  p: 1.5,
                  borderRadius: 2,
                  backgroundColor: "#e3f2fd",
                  display: "flex",
                  alignItems: "center",
                  justifyContent: "center",
                }}
              >
                <HelpCircle size={isMobile ? 20 : 24} color="#1976d2" />
              </Box>
              <Box>
                <Typography
                  variant={isMobile ? "h5" : "h4"}
                  sx={{
                    fontWeight: 700,
                    color: "#1a1a1a",
                    fontSize: { xs: "1.5rem", sm: "1.75rem", md: "2rem" },
                  }}
                >
                  Frequently Asked Questions
                </Typography>
              </Box>
            </Stack>

            {/* FAQ List */}
            <Box sx={{ mb: { xs: 3, sm: 4 } }}>
              {faqs.map((faq) => (
                <FAQItem key={faq.id} faq={faq} />
              ))}
            </Box>

            {/* Add New FAQ Button */}
            <Box sx={{ display: "flex", justifyContent: "center" }}>
              <Button
                variant="outlined"
                startIcon={<Plus size={18} />}
                onClick={() => setShowAddModal(true)}
                sx={{
                  borderRadius: 2,
                  textTransform: "none",
                  fontSize: { xs: "0.9rem", sm: "1rem" },
                  px: { xs: 3, sm: 4 },
                  py: { xs: 1.5, sm: 2 },
                  borderColor: "#e0e0e0",
                  color: "#666",
                  "&:hover": {
                    borderColor: "#1976d2",
                    backgroundColor: "#f8f9ff",
                    color: "#1976d2",
                  },
                }}
              >
                Add New FAQ
              </Button>
            </Box>
          </CardContent>
        </Card>

        {/* Add FAQ Modal */}
        <Dialog
          open={showAddModal}
          onClose={handleCloseModal}
          maxWidth="md"
          fullWidth
          fullScreen={isMobile}
          PaperProps={{
            sx: {
              borderRadius: isMobile ? 0 : 3,
              m: isMobile ? 0 : 2,
            },
          }}
        >
          <DialogTitle
            sx={{
              pb: 1,
              fontSize: { xs: "1.2rem", sm: "1.5rem" },
              fontWeight: 600,
              display: "flex",
              alignItems: "center",
              justifyContent: "space-between",
              borderBottom: "1px solid #f0f0f0",
            }}
          >
            <Box>
              <Typography variant="h6" sx={{ fontWeight: 600 }}>
                Add New FAQ
              </Typography>
              <Typography variant="body2" color="text.secondary" sx={{ fontSize: "0.85rem" }}>
                Create a new frequently asked question
              </Typography>
            </Box>
            <IconButton onClick={handleCloseModal} size="small" sx={{ color: "#666" }}>
              <X size={20} />
            </IconButton>
          </DialogTitle>

          <DialogContent sx={{ pt: 3 }}>
            <Stack spacing={3}>
              <TextField
                fullWidth
                label="Question"
                value={newFAQ.question}
                onChange={(e) => setNewFAQ((prev) => ({ ...prev, question: e.target.value }))}
                placeholder="Enter the frequently asked question..."
                size={isMobile ? "small" : "medium"}
                sx={{
                  "& .MuiOutlinedInput-root": {
                    borderRadius: 2,
                  },
                }}
              />
              <TextField
                fullWidth
                label="Answer"
                multiline
                rows={4}
                value={newFAQ.answer}
                onChange={(e) => setNewFAQ((prev) => ({ ...prev, answer: e.target.value }))}
                placeholder="Enter the answer to this question..."
                size={isMobile ? "small" : "medium"}
                sx={{
                  "& .MuiOutlinedInput-root": {
                    borderRadius: 2,
                  },
                }}
              />
            </Stack>
          </DialogContent>

          <DialogActions sx={{ p: 3, pt: 2, borderTop: "1px solid #f0f0f0" }}>
            <Stack direction={{ xs: "column", sm: "row" }} spacing={2} sx={{ width: "100%" }}>
              <Button
                onClick={handleCloseModal}
                sx={{
                  flex: 1,
                  py: 1.5,
                  borderRadius: 2,
                  textTransform: "none",
                  fontSize: "1rem",
                  fontWeight: 600,
                  color: "#666",
                }}
              >
                Cancel
              </Button>
              <Button
                onClick={handleAddFAQ}
                variant="contained"
                startIcon={<Save size={18} />}
                disabled={!newFAQ.question.trim() || !newFAQ.answer.trim()}
                sx={{
                  flex: 1,
                  py: 1.5,
                  borderRadius: 2,
                  textTransform: "none",
                  fontSize: "1rem",
                  fontWeight: 600,
                  backgroundColor: "#1a1a1a",
                  "&:hover": {
                    backgroundColor: "#333",
                  },
                  "&:disabled": {
                    backgroundColor: "#ccc",
                    color: "#999",
                  },
                }}
              >
                Add FAQ
              </Button>
            </Stack>
          </DialogActions>
        </Dialog>
      </Box>
    </Box>
  )
}

export default FAQComponent
