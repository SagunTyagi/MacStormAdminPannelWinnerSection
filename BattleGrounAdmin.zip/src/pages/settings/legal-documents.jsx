"use client"
import { useState } from "react"
import {
  Box,
  Card,
  CardContent,
  Typography,
  Button,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  IconButton,
  Stack,
  Chip,
  Tab,
  Tabs,
  TextField,
  useTheme,
  useMediaQuery,
  Paper,
} from "@mui/material"
import { FileText, Edit, Eye, X, Save, Upload, CheckCircle } from "lucide-react"

const LegalDocuments = () => {
  const theme = useTheme()
  const isMobile = useMediaQuery(theme.breakpoints.down("sm"))
  const isTablet = useMediaQuery(theme.breakpoints.between("sm", "md"))

  // State management
  const [showEditModal, setShowEditModal] = useState(false)
  const [activeTab, setActiveTab] = useState(0) // 0 for Edit, 1 for Preview
  const [selectedDocument, setSelectedDocument] = useState(null)
  const [markdownContent, setMarkdownContent] = useState("")

  const [documents, setDocuments] = useState([
    {
      id: 1,
      title: "Terms & Conditions",
      version: "v2.4",
      status: "Live",
      lastUpdated: "2025-07-22 07:26:00",
      updatedBy: "John Smith",
      content: "# Terms & Conditions\n\nWelcome to BattleNation...\nand",
    },
    {
      id: 2,
      title: "Privacy Policy",
      version: "v1.8",
      status: "Live",
      lastUpdated: "2024-01-05 11:22:33",
      updatedBy: "Sarah Johnson",
      content: "# Privacy Policy\n\nYour privacy is important to us...",
    },
    {
      id: 3,
      title: "Refund Policy",
      version: "v1.3",
      status: "Live",
      lastUpdated: "2023-12-20 09:15:45",
      updatedBy: "Mike Chen",
      content: "# Refund Policy\n\nWe offer refunds under certain conditions...",
    },
    {
      id: 4,
      title: "Responsible Gaming Policy",
      version: "v1.1",
      status: "Live",
      lastUpdated: "2023-11-15 16:45:22",
      updatedBy: "Lisa Wong",
      content: "# Responsible Gaming Policy\n\nWe are committed to responsible gaming...",
    },
  ])

  // Handlers
  const handleEditDocument = (document) => {
    setSelectedDocument(document)
    setMarkdownContent(document.content)
    setShowEditModal(true)
    setActiveTab(0) // Start with Edit tab
  }

  const handleTabChange = (event, newValue) => {
    setActiveTab(newValue)
  }

  const handleSaveDraft = () => {
    // Handle save draft logic
    console.log("Save draft:", markdownContent)
  }

  const handlePublishLive = () => {
    // Handle publish logic
    if (selectedDocument) {
      setDocuments((prev) =>
        prev.map((doc) =>
          doc.id === selectedDocument.id
            ? {
                ...doc,
                content: markdownContent,
                lastUpdated: new Date().toISOString().slice(0, 19).replace("T", " "),
              }
            : doc,
        ),
      )
    }
    setShowEditModal(false)
  }

  const handleCloseModal = () => {
    setShowEditModal(false)
    setSelectedDocument(null)
    setMarkdownContent("")
    setActiveTab(0)
  }

  // Simple markdown to HTML converter for preview
  const renderMarkdown = (content) => {
    return content
      .replace(/^# (.*$)/gm, "<h1>$1</h1>")
      .replace(/^## (.*$)/gm, "<h2>$1</h2>")
      .replace(/^### (.*$)/gm, "<h3>$1</h3>")
      .replace(/\n/g, "<br/>")
  }

  const DocumentCard = ({ document }) => (
    <Paper
      elevation={1}
      sx={{
        p: { xs: 2, sm: 3 },
        mb: 2,
        borderRadius: 2,
        border: "1px solid #f0f0f0",
        "&:hover": {
          borderColor: "#e3f2fd",
          backgroundColor: "#fafafa",
        },
      }}
    >
      <Stack
        direction={{ xs: "column", sm: "row" }}
        justifyContent="space-between"
        alignItems={{ xs: "flex-start", sm: "center" }}
        spacing={2}
      >
        <Box sx={{ flex: 1 }}>
          <Stack
            direction={{ xs: "column", sm: "row" }}
            alignItems={{ xs: "flex-start", sm: "center" }}
            spacing={{ xs: 1, sm: 2 }}
            sx={{ mb: 1 }}
          >
            <Typography
              variant="h6"
              sx={{
                fontWeight: 600,
                fontSize: { xs: "1rem", sm: "1.1rem" },
              }}
            >
              {document.title}
            </Typography>
            <Stack direction="row" spacing={1}>
              <Chip label={document.version} size="small" variant="outlined" sx={{ fontSize: "0.75rem", height: 24 }} />
              <Chip
                label={document.status}
                size="small"
                color="success"
                icon={<CheckCircle size={14} />}
                sx={{ fontSize: "0.75rem", height: 24 }}
              />
            </Stack>
          </Stack>
          <Typography variant="body2" color="text.secondary" sx={{ fontSize: { xs: "0.8rem", sm: "0.875rem" } }}>
            Last updated: {document.lastUpdated} by {document.updatedBy}
          </Typography>
        </Box>

        <Stack direction="row" spacing={1}>
          <Button
            variant="outlined"
            startIcon={<Edit size={16} />}
            onClick={() => handleEditDocument(document)}
            size={isMobile ? "small" : "medium"}
            sx={{
              borderRadius: 2,
              textTransform: "none",
              fontSize: { xs: "0.8rem", sm: "0.875rem" },
            }}
          >
            Edit
          </Button>
          <Button
            variant="contained"
            startIcon={<Upload size={16} />}
            size={isMobile ? "small" : "medium"}
            sx={{
              borderRadius: 2,
              textTransform: "none",
              fontSize: { xs: "0.8rem", sm: "0.875rem" },
              backgroundColor: "#1a1a1a",
              "&:hover": {
                backgroundColor: "#333",
              },
            }}
          >
            Publish
          </Button>
        </Stack>
      </Stack>
    </Paper>
  )

  return (
    <Box
      sx={{
        minHeight: "100vh",
        backgroundColor: "#fafafa",
        py: { xs: 2, sm: 3, md: 4 },
      }}
    >
      <Box
        sx={{
          width: "95%",
          maxWidth: "95%",
          mx: "auto",
          px: { xs: 1, sm: 1.5, md: 2 },
        }}
      >
        {/* Legal Documents Content */}
        <Card
          elevation={2}
          sx={{
            borderRadius: { xs: 2, sm: 3 },
            backgroundColor: "#ffffff",
            border: "1px solid #f0f0f0",
          }}
        >
          <CardContent
            sx={{
              p: { xs: 2, sm: 3, md: 4 },
              "&:last-child": { pb: { xs: 2, sm: 3, md: 4 } },
            }}
          >
            {/* Header */}
            <Stack direction="row" alignItems="center" spacing={2} sx={{ mb: { xs: 3, sm: 4 } }}>
              <Box
                sx={{
                  p: 1.5,
                  borderRadius: 2,
                  backgroundColor: "#e3f2fd",
                  display: "flex",
                  alignItems: "center",
                  justifyContent: "center",
                }}
              >
                <FileText size={isMobile ? 20 : 24} color="#1976d2" />
              </Box>
              <Box>
                <Typography
                  variant={isMobile ? "h5" : "h4"}
                  sx={{
                    fontWeight: 700,
                    color: "#1a1a1a",
                    mb: 0.5,
                  }}
                >
                  Legal Documents
                </Typography>
                <Typography variant="body2" color="text.secondary" sx={{ fontSize: { xs: "0.8rem", sm: "0.875rem" } }}>
                  Manage legal documents with version control and markdown editing
                </Typography>
              </Box>
            </Stack>

            {/* Documents List */}
            <Box>
              {documents.map((document) => (
                <DocumentCard key={document.id} document={document} />
              ))}
            </Box>
          </CardContent>
        </Card>

        {/* Edit Modal */}
        <Dialog
          open={showEditModal}
          onClose={handleCloseModal}
          maxWidth="lg"
          fullWidth
          fullScreen={isMobile}
          PaperProps={{
            sx: {
              borderRadius: isMobile ? 0 : 3,
              m: isMobile ? 0 : 2,
              height: isMobile ? "100vh" : "80vh",
            },
          }}
        >
          <DialogTitle
            sx={{
              pb: 1,
              fontSize: { xs: "1.2rem", sm: "1.5rem" },
              fontWeight: 600,
              display: "flex",
              alignItems: "center",
              justifyContent: "space-between",
              borderBottom: "1px solid #f0f0f0",
            }}
          >
            <Box>
              <Typography variant="h6" sx={{ fontWeight: 600 }}>
                Edit {selectedDocument?.title}
              </Typography>
              <Typography variant="body2" color="text.secondary" sx={{ fontSize: "0.8rem" }}>
                Version {selectedDocument?.version} • Markdown Editor with Split Pane
              </Typography>
            </Box>
            <IconButton onClick={handleCloseModal} size="small" sx={{ color: "#666" }}>
              <X size={20} />
            </IconButton>
          </DialogTitle>

          <Box sx={{ borderBottom: "1px solid #f0f0f0" }}>
            <Tabs
              value={activeTab}
              onChange={handleTabChange}
              sx={{
                minHeight: 48,
                "& .MuiTab-root": {
                  textTransform: "none",
                  fontWeight: 600,
                  fontSize: { xs: "0.9rem", sm: "1rem" },
                  minHeight: 48,
                  backgroundColor: activeTab === 0 ? "#1a1a1a" : "transparent",
                  color: activeTab === 0 ? "white" : "#666",
                  "&.Mui-selected": {
                    backgroundColor: "#1a1a1a",
                    color: "white",
                  },
                },
                "& .MuiTabs-indicator": {
                  display: "none",
                },
              }}
            >
              <Tab
                icon={<Edit size={16} />}
                iconPosition="start"
                label="Edit"
                sx={{
                  backgroundColor: activeTab === 0 ? "#1a1a1a" : "transparent",
                  color: activeTab === 0 ? "white" : "#666",
                  "&.Mui-selected": {
                    backgroundColor: "#1a1a1a",
                    color: "white",
                  },
                }}
              />
              <Tab
                icon={<Eye size={16} />}
                iconPosition="start"
                label="Preview"
                sx={{
                  backgroundColor: activeTab === 1 ? "#1a1a1a" : "transparent",
                  color: activeTab === 1 ? "white" : "#666",
                  "&.Mui-selected": {
                    backgroundColor: "#1a1a1a",
                    color: "white",
                  },
                }}
              />
            </Tabs>
          </Box>

          <DialogContent sx={{ p: 0, height: "100%", overflow: "hidden" }}>
            <Stack direction={{ xs: "column", md: "row" }} sx={{ height: "100%" }}>
              {/* Edit Panel */}
              <Box
                sx={{
                  flex: 1,
                  p: 2,
                  borderRight: { xs: "none", md: "1px solid #f0f0f0" },
                  display: activeTab === 0 || !isMobile ? "block" : "none",
                }}
              >
                <Typography variant="subtitle2" sx={{ mb: 1, fontWeight: 600 }}>
                  Markdown Content
                </Typography>
                <TextField
                  multiline
                  fullWidth
                  value={markdownContent}
                  onChange={(e) => setMarkdownContent(e.target.value)}
                  placeholder="Enter markdown content..."
                  sx={{
                    height: "calc(100% - 40px)",
                    "& .MuiOutlinedInput-root": {
                      height: "100%",
                      alignItems: "flex-start",
                      fontFamily: "monospace",
                      fontSize: "0.9rem",
                    },
                    "& .MuiOutlinedInput-input": {
                      height: "100% !important",
                      overflow: "auto !important",
                    },
                  }}
                />
              </Box>

              {/* Preview Panel */}
              <Box
                sx={{
                  flex: 1,
                  p: 2,
                  backgroundColor: "#fafafa",
                  display: activeTab === 1 || !isMobile ? "block" : "none",
                }}
              >
                <Typography variant="subtitle2" sx={{ mb: 1, fontWeight: 600 }}>
                  Preview
                </Typography>
                <Box
                  sx={{
                    height: "calc(100% - 40px)",
                    overflow: "auto",
                    p: 2,
                    backgroundColor: "white",
                    borderRadius: 1,
                    border: "1px solid #e0e0e0",
                  }}
                  dangerouslySetInnerHTML={{
                    __html: renderMarkdown(markdownContent),
                  }}
                />
              </Box>
            </Stack>
          </DialogContent>

          <DialogActions sx={{ p: 2, borderTop: "1px solid #f0f0f0" }}>
            <Stack direction={{ xs: "column", sm: "row" }} spacing={2} sx={{ width: "100%" }}>
              <Button
                variant="outlined"
                startIcon={<Save size={18} />}
                onClick={handleSaveDraft}
                sx={{
                  flex: 1,
                  py: 1.5,
                  borderRadius: 2,
                  textTransform: "none",
                  fontSize: "1rem",
                  fontWeight: 600,
                }}
              >
                Save Draft
              </Button>
              <Button
                variant="contained"
                startIcon={<Upload size={18} />}
                onClick={handlePublishLive}
                sx={{
                  flex: 1,
                  py: 1.5,
                  borderRadius: 2,
                  textTransform: "none",
                  fontSize: "1rem",
                  fontWeight: 600,
                  backgroundColor: "#1a1a1a",
                  "&:hover": {
                    backgroundColor: "#333",
                  },
                }}
              >
                Publish Live
              </Button>
            </Stack>
          </DialogActions>
        </Dialog>
      </Box>
    </Box>
  )
}

export default LegalDocuments
