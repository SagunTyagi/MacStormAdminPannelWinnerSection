"use client"
import {
  Box,
  Card,
  CardContent,
  Typography,
  Stack,
  Avatar,
  IconButton,
  Paper,
  useTheme,
  useMediaQuery,
} from "@mui/material"
import { Info, ExternalLink, Users, CreditCard, Hash, Trophy } from "lucide-react"

const HowToPlay = () => {
  const theme = useTheme()
  const isMobile = useMediaQuery(theme.breakpoints.down("sm"))
  const isTablet = useMediaQuery(theme.breakpoints.between("sm", "md"))

  const steps = [
    {
      id: 1,
      title: "Create Your Account",
      description: "Download the app and create your BattleNation account with email verification.",
      icon: Users,
    },
    {
      id: 2,
      title: "Join or Create a Team",
      description: "Browse available teams or create your own team with friends.",
      icon: Users,
    },
    {
      id: 3,
      title: "Pay Tournament Entry",
      description: "Pay the entry fee using UPI, cards, or wallet balance.",
      icon: CreditCard,
    },
    {
      id: 4,
      title: "Get Your Match Code",
      description: "Receive unique match codes for each tournament round.",
      icon: Hash,
    },
    {
      id: 5,
      title: "Play and Submit Results",
      description: "Play your matches and upload screenshots for verification.",
      icon: Trophy,
    },
  ]

  const StepCard = ({ step, index }) => {
    const IconComponent = step.icon

    return (
      <Card
        elevation={1}
        sx={{
          mb: { xs: 1, sm: 1.5 },
          borderRadius: { xs: 1.5, sm: 2 },
          border: "1px solid #f0f0f0",
          transition: "all 0.2s ease-in-out",
          "&:hover": {
            elevation: 3,
            transform: "translateY(-1px)",
            borderColor: "#e3f2fd",
          },
        }}
      >
        <CardContent
          sx={{
            p: { xs: 1, sm: 1.5, md: 2 },
            "&:last-child": { pb: { xs: 1, sm: 1.5, md: 2 } },
          }}
        >
          <Stack
            direction={{ xs: "column", sm: "row" }}
            spacing={{ xs: 1, sm: 1.5 }}
            alignItems={{ xs: "flex-start", sm: "center" }}
          >
            {/* Step Number */}
            <Avatar
              sx={{
                bgcolor: "#1976d2",
                color: "white",
                width: { xs: 28, sm: 32, md: 36 },
                height: { xs: 28, sm: 32, md: 36 },
                fontSize: { xs: "0.8rem", sm: "0.9rem", md: "1rem" },
                fontWeight: 600,
                flexShrink: 0,
              }}
            >
              {step.id}
            </Avatar>

            {/* Content */}
            <Box sx={{ flex: 1, minWidth: 0 }}>
              <Stack
                direction={{ xs: "column", sm: "row" }}
                spacing={{ xs: 1, sm: 1.5 }}
                alignItems={{ xs: "flex-start", sm: "center" }}
              >
                <Box sx={{ flex: 1, minWidth: 0 }}>
                  <Typography
                    variant={isMobile ? "subtitle2" : "subtitle1"}
                    sx={{
                      fontWeight: 600,
                      mb: 0.25,
                      color: "#1a1a1a",
                      fontSize: { xs: "0.9rem", sm: "1rem", md: "1.1rem" },
                    }}
                  >
                    {step.title}
                  </Typography>
                  <Typography
                    variant="body2"
                    color="text.secondary"
                    sx={{
                      fontSize: { xs: "0.75rem", sm: "0.8rem" },
                      lineHeight: 1.4,
                    }}
                  >
                    {step.description}
                  </Typography>
                </Box>

                {/* Media Placeholder */}
                <Paper
                  elevation={0}
                  sx={{
                    width: { xs: "100%", sm: 120, md: 140 },
                    height: { xs: 60, sm: 50, md: 60 },
                    backgroundColor: "#f5f5f5",
                    borderRadius: 1,
                    display: "flex",
                    alignItems: "center",
                    justifyContent: "center",
                    border: "2px dashed #e0e0e0",
                    flexShrink: 0,
                  }}
                >
                  <Stack alignItems="center" spacing={0.25}>
                    <IconComponent size={isMobile ? 16 : 20} color="#9e9e9e" />
                    <Typography
                      variant="caption"
                      color="text.disabled"
                      sx={{ fontSize: { xs: "0.6rem", sm: "0.65rem" } }}
                    >
                      GIF/Image
                    </Typography>
                  </Stack>
                </Paper>

                {/* External Link Icon */}
                <IconButton
                  size="small"
                  sx={{
                    color: "#666",
                    "&:hover": {
                      color: "#1976d2",
                      backgroundColor: "#f3f4f6",
                    },
                    alignSelf: { xs: "flex-end", sm: "center" },
                    width: { xs: 28, sm: 32 },
                    height: { xs: 28, sm: 32 },
                  }}
                >
                  <ExternalLink size={isMobile ? 14 : 16} />
                </IconButton>
              </Stack>
            </Box>
          </Stack>
        </CardContent>
      </Card>
    )
  }

  return (
    <Box
      sx={{
        minHeight: "100vh",
        backgroundColor: "#fafafa",
        py: { xs: 1.5, sm: 2, md: 3 },
      }}
    >
      <Box
        sx={{
          width: "95%",
          maxWidth: "95%",
          mx: "auto",
          px: { xs: 1, sm: 1.5, md: 2 },
        }}
      >
        {/* Header */}
        <Card
          elevation={2}
          sx={{
            mb: { xs: 1.5, sm: 2 },
            borderRadius: { xs: 1.5, sm: 2, md: 3 },
            backgroundColor: "#ffffff",
            border: "1px solid #f0f0f0",
          }}
        >
          <CardContent
            sx={{
              p: { xs: 1.5, sm: 2, md: 2.5 },
              "&:last-child": { pb: { xs: 1.5, sm: 2, md: 2.5 } },
            }}
          >
            <Stack direction="row" alignItems="center" spacing={1.5} sx={{ mb: 1 }}>
              <Avatar
                sx={{
                  bgcolor: "#e3f2fd",
                  color: "#1976d2",
                  width: { xs: 32, sm: 36 },
                  height: { xs: 32, sm: 36 },
                }}
              >
                <Info size={isMobile ? 16 : 18} />
              </Avatar>
              <Typography
                variant={isMobile ? "h6" : "h5"}
                sx={{
                  fontWeight: 700,
                  color: "#1a1a1a",
                  fontSize: { xs: "1.2rem", sm: "1.5rem", md: "1.75rem" },
                }}
              >
                How to Play Guide
              </Typography>
            </Stack>
            <Typography
              variant="body2"
              color="text.secondary"
              sx={{
                fontSize: { xs: "0.75rem", sm: "0.8rem", md: "0.85rem" },
                lineHeight: 1.4,
                ml: { xs: 0, sm: 5 },
              }}
            >
              Step-by-step guide with markdown and GIF support
            </Typography>
          </CardContent>
        </Card>

        {/* Steps */}
        <Box>
          {steps.map((step, index) => (
            <StepCard key={step.id} step={step} index={index} />
          ))}
        </Box>

        {/* Footer */}
        <Card
          elevation={1}
          sx={{
            mt: { xs: 1.5, sm: 2 },
            borderRadius: { xs: 1.5, sm: 2 },
            backgroundColor: "#f8f9fa",
            border: "1px solid #e9ecef",
          }}
        >
          <CardContent
            sx={{
              p: { xs: 1, sm: 1.5 },
              textAlign: "center",
              "&:last-child": { pb: { xs: 1, sm: 1.5 } },
            }}
          >
            <Typography
              variant="body2"
              color="text.secondary"
              sx={{
                fontSize: { xs: "0.65rem", sm: "0.75rem" },
              }}
            >
              Need help? Contact our support team for assistance with any step.
            </Typography>
          </CardContent>
        </Card>
      </Box>
    </Box>
  )
}

export default HowToPlay
