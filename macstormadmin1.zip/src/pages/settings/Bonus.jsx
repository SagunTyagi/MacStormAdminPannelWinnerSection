import React from "react";

function Hello() {
  return <h1>Hello, React!</h1>;
}

export default Hello;
